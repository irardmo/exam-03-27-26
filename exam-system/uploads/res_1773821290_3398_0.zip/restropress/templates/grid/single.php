<?php
/**
 * A single fooditem inside of the [fooditems] shortcode.
 *
 * @since 1.0.0
 *
 * @package RPRESS
 * @category Template
 * @author RestroPress
 * @version 1.0.4
 */
global $rpress_fooditem_shortcode_item_atts, $rpress_fooditem_shortcode_item_i, $rpress_food_item_cats;
$schema = rpress_add_schema_microdata() ? 'itemscope itemtype=http://schema.org/Product ' : '';
$post_terms = wp_get_post_terms( get_the_ID(), 'food-category' );
$term_id = $post_terms[0]->term_taxonomy_id;
$disable_category = rpress_get_option( 'disable_category_menu', false );
$option_view_food_items  = rpress_get_option( 'option_view_food_items' );

if( rpress_get_option( 'disable_styles', false ) == 0 && $disable_category && $option_view_food_items == "grid_view" ) {
  $food_item_class = "rpress-grid";
}
else {
  $food_item_class = "rpress-list";
}

// Get selected template from settings (default to 'list')
$template = rpress_get_option( 'template', 'list' );
$image_placeholder = rpress_get_option( 'enable_image_placeholder', false );
$has_thumbnail = has_post_thumbnail( get_the_ID() );

if ( ! $has_thumbnail && $image_placeholder == 0 ) {
    $image_placeholder_cls = 'image-placeholder-disabled';
} else {
    $image_placeholder_cls = '';
}

$description = get_post_field( 'post_excerpt', get_the_ID() );
if ( '' === trim( $description ) ) {
	$description = get_post_field( 'post_content', get_the_ID() );
}

$has_description   = '' !== trim( wp_strip_all_tags( $description ) );
$no_img_no_desc_cls = ( ! $has_thumbnail && ! $has_description ) ? 'rp-no-img-no-desc' : '';
if(rpress_fooditem_available($id)) {
	$product_available_class = "";
} else {
	$product_available_class = "product_not_available";
}
$tags = get_the_terms( get_the_ID(), 'fooditem_tag' );
$has_tags = ( $tags && ! is_wp_error( $tags ) ) ? 'has-tags' : '';
?>
<div 
    <?php echo esc_html( $schema ); ?>
    class="<?php 
        echo esc_attr( $has_tags ) . ' ' . 
             esc_attr( $product_available_class ) . ' ' . 
             esc_attr( apply_filters( 
                 'rpress_fooditem_class', 
                 'rpress_fooditem', 
                 get_the_ID(), 
                 $rpress_fooditem_shortcode_item_atts, 
                 $rpress_fooditem_shortcode_item_i 
             ) ) . ' ' . 
             esc_attr( $food_item_class ); 
    ?>" 
    data-term-id="<?php echo esc_attr( $term_id ); ?>" 
    id="rpress_fooditem_<?php the_ID(); ?>">
<?php $img_wrp = ( ! $has_thumbnail ) ? 'rp-no-img' : ''; ?>
	<div class="<?php echo  esc_attr( $image_placeholder_cls ) . ' ' . esc_attr( $img_wrp ) . ' ' . esc_attr( $no_img_no_desc_cls ) . ' ' . esc_attr( apply_filters( 'rpress_fooditem_inner_class', 'rpress_fooditem_inner', get_the_ID(), $rpress_fooditem_shortcode_item_atts, $rpress_fooditem_shortcode_item_i ) ); ?>">
		<?php do_action( 'rpress_fooditem_before' ); ?>
		<div class="rp-col-md-4 rp-col-xs-4 rp-col-sm-3 rp-grid-view-wrap">
			<?php
			rpress_get_template_part( $template . '/content-image' );
			do_action( 'rpress_fooditem_after_thumbnail' );
			?>
		</div>
		<div class="rp-col-md-8 rp-col-xs-8 rp-col-sm-9">
			<?php
			rpress_get_template_part( $template . '/fooditem-type' );	
			rpress_get_template_part( $template . '/content-title' );
			do_action( 'rpress_fooditem_after_title' );
			rpress_get_template_part( $template . '/content-cart-button' );
			do_action( 'rpress_fooditem_after_cart_button' );
			?>
		</div>
		<?php do_action( 'rpress_fooditem_after' ); ?>
	</div>
</div>
