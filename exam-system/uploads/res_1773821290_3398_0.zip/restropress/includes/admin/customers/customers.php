<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Customers Page
 *
 * Renders the customers page contents.
 *
 * @since  1.0.0
 * @return void
*/
function rpress_customers_page() {
	$default_views = rpress_customer_views();
	$requested_view = isset( $_GET['view'] ) ? sanitize_text_field( $_GET['view'] ) : 'customers';
	if ( array_key_exists( $requested_view, $default_views ) && is_callable( $default_views[$requested_view] ) ) {
		rpress_render_customer_view( $requested_view, $default_views );
	} else {
		rpress_customers_list();
	}
}
/**
 * Register the views for customer management
 *
 * @since  1.0.0
 * @return array Array of views and their callbacks
 */
function rpress_customer_views() {
	$views = array();
	return apply_filters( 'rpress_customer_views', $views );
}
/**
 * Register the tabs for customer management
 *
 * @since  1.0.0
 * @return array Array of tabs for the customer
 */
function rpress_customer_tabs() {
	$tabs = array();
	return apply_filters( 'rpress_customer_tabs', $tabs );
}
/**
 * List table of customers
 *
 * @since  1.0.0
 * @return void
 */
function rpress_customers_list() {
	include( dirname( __FILE__ ) . '/class-customer-table.php' );
	$customers_table = new RPRESS_Customer_Reports_Table();
	$customers_table->prepare_items();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Customers', 'restropress' ); ?></h1>
		<?php do_action( 'rpress_customers_table_top' ); ?>
		<form id="rpress-customers-filter" method="get" action="<?php echo esc_url( admin_url( 'admin.php?page=rpress-customers' ) ); ?>">
			<?php
			$customers_table->search_box( esc_html__( 'Search Customers', 'restropress' ), 'rpress-customers' );
			$customers_table->display();
			?>
			<input type="hidden" name="page" value="rpress-customers" />
			<input type="hidden" name="view" value="customers" />
		</form>
		<?php do_action( 'rpress_customers_table_bottom' ); ?>
	</div>
	<?php
}
/**
 * Renders the customer view wrapper
 *
 * @since  1.0.0
 * @param  string $view      The View being requested
 * @param  array $callbacks  The Registered views and their callback functions
 * @return void
 */
function rpress_render_customer_view( $view, $callbacks ) {
	$render = true;
	$customer_view_role = apply_filters( 'rpress_view_customers_role', 'view_shop_reports' );
	if ( ! current_user_can( $customer_view_role ) ) {
		rpress_set_error( 'rpress-no-access', __( 'You are not permitted to view this data.', 'restropress' ) );
		$render = false;
	}
	if ( ! isset( $_GET['id'] ) || ! is_numeric( $_GET['id'] ) ) {
		rpress_set_error( 'rpress-invalid_customer', __( 'Invalid Customer ID Provided.', 'restropress' ) );
		$render = false;
	}
	$customer_id = absint( $_GET['id'] );
	$customer    = new RPRESS_Customer( $customer_id );
	if ( empty( $customer->id ) ) {
		rpress_set_error( 'rpress-invalid_customer', __( 'Invalid Customer ID Provided.', 'restropress' ) );
		$render = false;
	}
	$customer_tabs = rpress_customer_tabs();
	?>
	<div class='wrap'>
		<h2>
			<?php esc_html_e( 'Customer Details', 'restropress' ); ?>
			<?php do_action( 'rpress_after_customer_details_header', $customer ); ?>
		</h2>
		<?php if ( rpress_get_errors() ) :?>
			<div class="error settings-error">
				<?php rpress_print_errors(); ?>
			</div>
		<?php endif; ?>
		<?php if ( $customer && $render ) : ?>
			<div id="rpress-item-wrapper" class="rpress-item-has-tabs rpress-clearfix">
				<div id="rpress-item-tab-wrapper" class="customer-tab-wrapper">
					<ul id="rpress-item-tab-wrapper-list" class="customer-tab-wrapper-list">
						<?php foreach ( $customer_tabs as $key => $tab ) : ?>
							<?php $active = $key === $view ? true : false; ?>
							<?php $class  = $active ? 'active' : 'inactive'; ?>
							<li class="<?php echo sanitize_html_class( $class ); ?>">
								<?php
								// prevent double "Customer" output from extensions
								$tab['title'] = preg_replace("(^Customer )","",$tab['title']);
								// rpress item tab full title
								$tab_title = sprintf( 
									/* translators: 1: text, 2: tab */
									_x( 'Customer %s', 'Customer Details page tab title', 'restropress' ), esc_attr( $tab[ 'title' ] ) );
								// aria-label output
								$aria_label = ' aria-label="' . $tab_title . '"';
								?>
								<?php if ( ! $active ) : ?>
									<a href="<?php echo esc_url( admin_url( 'admin.php?page=rpress-customers&view=' . $key . '&id=' . $customer->id . '#wpbody-content' ) ); ?>"<?php echo esc_attr( $aria_label ); ?>>
								<?php endif; ?>
									<span class="rpress-item-tab-label-wrap"<?php echo $active ? esc_attr( $aria_label ) : ''; ?>>
										<span class="dashicons <?php echo sanitize_html_class( $tab['dashicon'] ); ?>" aria-hidden="true"></span>
										<span class="rpress-item-tab-label"><?php echo esc_attr( $tab['title'] ); ?></span>
									</span>
								<?php if ( ! $active ) : ?>
									</a>
								<?php endif; ?>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
				<div id="rpress-item-card-wrapper" class="rpress-customer-card-wrapper" style="float: left">
					<?php call_user_func( $callbacks[ $view ], $customer ); ?>
				</div>
			</div>
		<?php endif; ?>
	</div>
	<?php
}
/**
 * View a customer
 *
 * @since  1.0.0
 * @param  $customer The Customer object being displayed
 * @return void
 */
function rpress_customers_view( $customer ) {
	$customer_edit_role = apply_filters( 'rpress_edit_customers_role', 'edit_shop_payments' );
	?>
	<?php do_action( 'rpress_customer_card_top', $customer ); ?>
	<div class="info-wrapper customer-section">
		<form id="edit-customer-info" method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=rpress-customers&view=overview&id=' . $customer->id ) ) ; ?>">
			<div class="rpress-item-info customer-info">
				<div class="avatar-wrap left" id="customer-avatar">
					<?php echo get_avatar( $customer->email ); ?><br />
					<?php if ( current_user_can( $customer_edit_role ) ): ?>
						<span class="info-item editable customer-edit-link"><a href="#" id="edit-customer"><?php esc_html_e( 'Edit Customer', 'restropress' ); ?></a></span>
						<?php do_action( 'rpress_after_customer_edit_link', $customer ); ?>
					<?php endif; ?>
				</div>
				<div class="customer-id right">
					#<?php echo esc_html( absint( $customer->id ) ) ; ?>
				</div>
				<div class="customer-address-wrapper right">
				<?php if ( isset( $customer->user_id ) && $customer->user_id > 0 ) : ?>
					<?php
						$address = get_user_meta( $customer->user_id, '_rpress_user_address', true );
						$defaults = array(
							'line1'   => '',
							'line2'   => '',
							'city'    => '',
							'state'   => '',
							'country' => '',
							'zip'     => ''
						);
						$address = wp_parse_args( $address, $defaults );
					?>
					<strong><?php esc_html_e( 'Customer Address', 'restropress' ); ?></strong>
					<span class="customer-address info-item editable">
						<span class="info-item" data-key="line1"><?php echo esc_html( $address['line1'] ); ?></span>
						<span class="info-item" data-key="line2"><?php echo esc_html( $address['line2'] ); ?></span>
						<span class="info-item" data-key="city"><?php echo esc_html( $address['city'] ); ?></span>
						<span class="info-item" data-key="state"><?php echo esc_html( rpress_get_state_name( $address['country'], $address['state'] ) ); ?></span>
						<span class="info-item" data-key="country"><?php echo wp_kses_post( rpress_get_country_name( $address['country'] ) ); ?></span>
						<span class="info-item" data-key="zip"><?php echo esc_html( $address['zip'] ); ?></span>
					</span>
					<span class="customer-address info-item edit-item">
						<input class="info-item" type="text" data-key="line1" name="customerinfo[line1]" placeholder="<?php esc_html_e( 'Address 1', 'restropress' ); ?>" value="<?php echo esc_attr( $address['line1'] ); ?>" />
						<input class="info-item" type="text" data-key="line2" name="customerinfo[line2]" placeholder="<?php esc_html_e( 'Address 2', 'restropress' ); ?>" value="<?php echo esc_attr( $address['line2'] ); ?>" />
						<input class="info-item" type="text" data-key="city" name="customerinfo[city]" placeholder="<?php esc_html_e( 'City', 'restropress' ); ?>" value="<?php echo esc_attr( $address['city'] ); ?>" />
						<select data-key="country" name="customerinfo[country]" id="billing_country" class="billing_country rpress-select edit-item">
							<?php
							$selected_country = wp_kses_post( $address['country'] );
							$countries = rpress_get_country_list();
							foreach( $countries as $country_code => $country ) {
								echo '<option value="' . esc_attr( $country_code ) . '"' . selected( $country_code, $selected_country, false ) . '>' . wp_kses_post( $country ) . '</option>';
							}
							?>
						</select>
						<?php
						$selected_state = rpress_get_shop_state();
						$states         = rpress_get_states( $selected_country );
						$selected_state = isset( $address['state'] ) ? $address['state'] : $selected_state;
						if( ! empty( $states ) ) : ?>
						<select data-key="state" name="customerinfo[state]" id="card_state" class="card_state rpress-select info-item">
							<?php
								foreach( $states as $state_code => $state ) {
									echo '<option value="' . esc_attr( $state_code ) . '"' . selected( $state_code, $selected_state, false ) . '>' . wp_kses_post( $state ) . '</option>';
								}
							?>
						</select>
						<?php else : ?>
						<input type="text" data-key="state" name="customerinfo[state]" id="card_state" class="card_state rpress-input info-item" placeholder="<?php esc_html_e( 'State / Province', 'restropress' ); ?>" value="<?php echo esc_attr( $address['state'] ); ?>"/>
						<?php endif; ?>
						<input class="info-item" type="text" data-key="zip" name="customerinfo[zip]" placeholder="<?php esc_html_e( 'Postal', 'restropress' ); ?>" value="<?php echo esc_attr( $address['zip'] ); ?>" />
					</span>
				<?php endif; ?>
				</div>
				<div class="customer-main-wrapper left">
					<span class="customer-name info-item edit-item"><input size="15" data-key="name" name="customerinfo[name]" type="text" value="<?php echo esc_attr( $customer->name ); ?>" placeholder="<?php esc_html_e( 'Customer Name', 'restropress' ); ?>" /></span>
					<span class="customer-name info-item editable"><span data-key="name"><?php echo esc_html( $customer->name ); ?></span></span>
					<span class="customer-name info-item edit-item"><input size="20" data-key="email" name="customerinfo[email]" type="text" value="<?php echo esc_attr( $customer->email ); ?>" placeholder="<?php esc_html_e( 'Customer Email', 'restropress' ); ?>" /></span>
					<span class="customer-email info-item editable" data-key="email"><?php echo esc_html( $customer->email ); ?></span>
					<span class="customer-since info-item">
						<?php
						printf(
							/* translators: The date. */
							esc_html__( 'Customer since %s', 'restropress' ),
							esc_html( date_i18n( get_option( 'date_format' ), strtotime( $customer->date_created ) ) )
						);
						?>
					</span>
					<span class="customer-user-id info-item edit-item">
						<?php
						$user_id    = $customer->user_id > 0 ? $customer->user_id : '';
						$data_atts  = array( 'key' => 'user_login', 'exclude' => $user_id );
						$user_args  = array(
							'name'  => 'customerinfo[user_login]',
							'class' => 'rpress-user-dropdown',
							'data'  => $data_atts,
						);
						if( ! empty( $user_id ) ) {
							$userdata = get_userdata( $user_id );
							$user_args['value'] = $userdata->user_login;
						}
						echo esc_html( RPRESS()->html->ajax_user_search( $user_args ) );
						?>
						<input type="hidden" name="customerinfo[user_id]" data-key="user_id" value="<?php echo esc_attr( $customer->user_id ); ?>" />
					</span>
					<span class="customer-user-id info-item editable">
						<?php esc_html_e( 'User ID', 'restropress' ); ?>:&nbsp;
						<?php if( intval( $customer->user_id ) > 0 ) : ?>
							<span data-key="user_id"><a href="<?php echo esc_url( admin_url( 'user-edit.php?user_id=' . $customer->user_id ) ); ?>"><?php echo esc_html( $customer->user_id ); ?></a></span>
						<?php else : ?>
							<span data-key="user_id"><?php esc_html_e( 'none', 'restropress' ); ?></span>
						<?php endif; ?>
						<?php if ( current_user_can( $customer_edit_role ) && intval( $customer->user_id ) > 0 ) : ?>
							<span class="disconnect-user"> - <a id="disconnect-customer" href="#disconnect"><?php esc_html_e( 'Disconnect User', 'restropress' ); ?></a></span>
						<?php endif; ?>
					</span>
				</div>
			</div>
			<span id="customer-edit-actions" class="edit-item">
				<input type="hidden" data-key="id" name="customerinfo[id]" value="<?php echo esc_attr( $customer->id ); ?>" />
				<?php wp_nonce_field( 'edit-customer', '_wpnonce', false, true ); ?>
				<input type="hidden" name="rpress_action" value="edit-customer" />
				<input type="submit" id="rpress-edit-customer-save" class="button-secondary" value="<?php esc_html_e( 'Update Customer', 'restropress' ); ?>" />
				<a id="rpress-edit-customer-cancel" href="" class="delete"><?php esc_html_e( 'Cancel', 'restropress' ); ?></a>
			</span>
		</form>
	</div>
	<?php do_action( 'rpress_customer_before_stats', $customer ); ?>
	<div id="rpress-item-stats-wrapper" class="customer-stats-wrapper customer-section">
		<ul>
			<li>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=rpress-payment-history&customer=' . $customer->id ) ); ?>">
					<span class="dashicons dashicons-cart"></span>
					<?php echo esc_html( printf( 
						/* translators: 1: text, 2: customer */
						_n( '%d Completed Order', '%d Completed Orders', $customer->purchase_count, 'restropress' ), $customer->purchase_count ) ); ?>
				</a>
			</li>
			<?php do_action( 'rpress_customer_stats_list', $customer ); ?>
		</ul>
	</div>
	<?php do_action( 'rpress_customer_before_tables_wrapper', $customer ); ?>
	<div id="rpress-item-tables-wrapper" class="customer-tables-wrapper customer-section">
		<?php do_action( 'rpress_customer_before_tables', $customer ); ?>
		<h3>
			<?php esc_html_e( 'Customer Emails', 'restropress' ); ?>
			<span alt="f223" class="rpress-help-tip dashicons dashicons-editor-help" title="<?php esc_html_e( 'This customer can use any of the emails listed here when making new purchases.', 'restropress' ); ?>"></span>
		</h3>
		<?php
			$primary_email     = $customer->email;
			$additional_emails = $customer->emails;
			$all_emails = array( 'primary' => $primary_email );
			foreach ( $additional_emails as $key => $email ) {
				if ( $primary_email === $email ) {
					continue;
				}
				$all_emails[ $key ] = $email;
			}
		?>
		<table class="wp-list-table widefat striped emails">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Email', 'restropress' ); ?></th>
					<th><?php esc_html_e( 'Actions', 'restropress' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if ( ! empty( $all_emails ) ) : ?>
					<?php foreach ( $all_emails as $key => $email ) : ?>
						<tr data-key="<?php echo esc_attr( $key ); ?>">
							<td>
								<?php echo esc_html( $email ); ?>
								<?php if ( 'primary' === $key ) : ?>
									<span class="dashicons dashicons-star-filled primary-email-icon"></span>
								<?php endif; ?>
							</td>
							<td>
								<?php if ( 'primary' !== $key ) : ?>
									<?php
										$base_url    = admin_url( 'admin.php?page=rpress-customers&view=overview&id=' . $customer->id );
										$promote_url = wp_nonce_url( add_query_arg( array( 'email' => rawurlencode( $email ), 'rpress_action' => 'customer-primary-email'), $base_url ), 'rpress-set-customer-primary-email' );
										$remove_url  = wp_nonce_url( add_query_arg( array( 'email' => rawurlencode( $email ), 'rpress_action' => 'customer-remove-email'), $base_url ), 'rpress-remove-customer-email' );
									?>
									<a href="<?php echo esc_url( $promote_url ); ?>"><?php esc_html_e( 'Make Primary', 'restropress' ); ?></a>
									&nbsp;|&nbsp;
									<a href="<?php echo esc_url( $remove_url ); ?>" class="delete"><?php esc_html_e( 'Remove', 'restropress' ); ?></a>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
					<tr class="add-customer-email-row">
						<td colspan="2" class="add-customer-email-td">
							<div class="add-customer-email-wrapper">
								<input type="hidden" name="customer-id" value="<?php echo esc_attr( $customer->id ); ?>" />
								<?php wp_nonce_field( 'rpress-add-customer-email', 'add_email_nonce', false, true ); ?>
								<input type="email" name="additional-email" value="" placeholder="<?php esc_html_e( 'Email Address', 'restropress' ); ?>" />&nbsp;
								<input type="checkbox" name="make-additional-primary" value="1" id="make-additional-primary" />&nbsp;<label for="make-additional-primary"><?php esc_html_e( 'Make Primary', 'restropress' ); ?></label>
								<button class="button-secondary rpress-add-customer-email" id="add-customer-email" style="margin: 6px 0;"><?php esc_html_e( 'Add Email', 'restropress' ); ?></button>
								<span class="spinner"></span>
							</div>
							<div class="notice-container"></div>
						</td>
					</tr>
				<?php else: ?>
					<tr><td colspan="2"><?php esc_html_e( 'No Emails Found', 'restropress' ); ?></td></tr>
				<?php endif; ?>
			</tbody>
		</table>
		<h3><?php esc_html_e( 'Recent Orders', 'restropress' ); ?></h3>
		<?php
			$payment_ids = explode( ',', $customer->payment_ids );
			$payments    = rpress_get_payments( array( 'post__in' => $payment_ids ) );
			$payments    = array_slice( $payments, 0, 10 );
		?>
		<table class="wp-list-table widefat striped payments">
			<thead>
				<tr>
					<th><?php esc_html_e( 'ID', 'restropress' ); ?></th>
					<th><?php esc_html_e( 'Amount', 'restropress' ); ?></th>
					<th><?php esc_html_e( 'Date', 'restropress' ); ?></th>
					<th><?php esc_html_e( 'Status', 'restropress' ); ?></th>
					<th><?php esc_html_e( 'Actions', 'restropress' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if ( ! empty( $payments ) ) : ?>
					<?php foreach ( $payments as $payment ) : ?>
						<tr>
							<td><?php echo esc_html( absint( $payment->ID ) ); ?></td>
							<td><?php echo esc_html( rpress_payment_amount( $payment->ID ) ); ?></td>
							<td><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $payment->post_date ) ) ); ?></td>
							<td><?php echo esc_html( rpress_get_payment_status( $payment, true ) ); ?></td>
							<td>
								<a href="<?php echo esc_url( admin_url( 'admin.php?page=rpress-payment-history&view=view-order-details&id=' . $payment->ID ) ); ?>">
									<?php esc_html_e( 'View Details', 'restropress' ); ?>
								</a>
								<?php do_action( 'rpress_customer_recent_purchases_actions', $customer, $payment ); ?>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php else: ?>
					<tr><td colspan="5"><?php esc_html_e( 'No Payments Found', 'restropress' ); ?></td></tr>
				<?php endif; ?>
			</tbody>
		</table>
		<h3><?php echo esc_html__( 'Ordered Item', 'restropress' ); rpress_get_label_plural() ?></h3>
		<?php
			$fooditems = rpress_get_users_ordered_products( $customer->email );
		?>
		<table class="wp-list-table widefat striped fooditems">
			<thead>
				<tr>
					<th>Item</th>
					<th width="120px"><?php esc_html_e( 'Actions', 'restropress' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if ( ! empty( $fooditems ) ) : ?>
					<?php foreach ( $fooditems as $fooditem ) : ?>
						<tr>
							<td><?php echo esc_html( $fooditem->post_title ); ?></td>
							<td>
								<a href="<?php echo esc_url( admin_url( 'post.php?action=edit&post=' . $fooditem->ID ) ); ?>">
									<?php esc_html_e( 'View Item', 'restropress' ); ?>
								</a>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php else: ?>
					<tr><td colspan="2"><?php echo esc_html( 'No %s Found', 'restropress' ); rpress_get_label_plural() ?></td></tr>
				<?php endif; ?>
			</tbody>
		</table>
		<?php do_action( 'rpress_customer_after_tables', $customer ); ?>
	</div>
	<?php do_action( 'rpress_customer_card_bottom', $customer ); ?>
	<?php
}
/**
 * View the notes of a customer
 *
 * @since  1.0.0
 * @param  $customer The Customer being displayed
 * @return void
 */
function rpress_customer_notes_view( $customer ) {
	$paged       = isset( $_GET['paged'] ) && is_numeric( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1;
	$paged       = absint( $paged );
	$note_count  = $customer->get_notes_count();
	$per_page    = apply_filters( 'rpress_customer_notes_per_page', 20 );
	$total_pages = ceil( $note_count / $per_page );
	$customer_notes = $customer->get_notes( $per_page, $paged );
	?>
	<div id="rpress-item-notes-wrapper">
		<div class="rpress-item-notes-header">
			<?php echo get_avatar( $customer->email, 30 ); ?> <span><?php echo esc_html( $customer->name ); ?></span>
		</div>
		<?php
		$show_agree_to_terms   = rpress_get_option( 'show_agree_to_terms', false );
		$show_agree_to_privacy = rpress_get_option( 'show_agree_to_privacy_policy', false );
		$agreement_timestamps = $customer->get_meta( 'agree_to_terms_time', false );
		$privacy_timestamps   = $customer->get_meta( 'agree_to_privacy_time', false );
		$payments = rpress_get_payments( array(
			'output'         => 'payments',
			'post__in'       => explode( ',', $customer->payment_ids ),
			'orderby'        => 'date',
			'posts_per_page' => 1
		) );
		$last_payment_date = '';
		foreach ( $payments as $payment ) {
			if ( empty( $payment->gateway ) ) {
				continue;
			}
			// We should be using `date` here, as that is the date the button was clicked.
			$last_payment_date = strtotime( $payment->date );
			break;
		}
		if ( is_array( $agreement_timestamps ) ) {
			$agreement_timestamp = array_pop( $agreement_timestamps );
		}
		if ( is_array( $privacy_timestamps ) ) {
			$privacy_timestamp = array_pop( $privacy_timestamps );
		}
		?>
		<h3><?php esc_html_e( 'Agreements', 'restropress' ); ?></h3>
		<span class="customer-terms-agreement-date info-item">
			<?php esc_html_e( 'Last Agreed to Terms', 'restropress' ); ?>:
			<?php if ( ! empty( $agreement_timestamp ) ) : ?>
				<?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' H:i:s', $agreement_timestamp ) ); ?>
				<?php if ( ! empty( $agreement_timestamps ) ) : ?>
					<?php
					$tooltip_text = esc_html__( 'Previous Agreement Dates', 'restropress' ) . "\n";

					foreach ( $agreement_timestamps as $timestamp ) {
						$tooltip_text .= esc_html( date_i18n( get_option( 'date_format' ) . ' H:i:s', $timestamp ) ) . "\n";
					}
					?>
					<span class="rpress-help-tip dashicons dashicons-editor-help" title="<?php echo esc_attr( $tooltip_text ); ?>"></span>
				<?php endif; ?>
			<?php else: ?>
				<?php
				if ( empty( $last_payment_date ) ) {
					esc_html_e( 'No date found.', 'restropress' );
				} else {
					echo esc_html( date_i18n( get_option( 'date_format' ) . ' H:i:s', $last_payment_date ) );
					?>
					<span alt="f223" class="rpress-help-tip dashicons dashicons-editor-help" title="<strong><?php esc_html_e( 'Estimated Privacy Policy Date', 'restropress' ); ?></strong><br /><?php esc_html_e( 'This customer made a purchase prior to agreement dates being logged, this is the date of their last purchase. If your site was displaying the agreement checkbox at that time, this is our best estimate as to when they last agreed to your terms.', 'restropress' ); ?>"></span>
					<?php
				}
				?>
			<?php endif; ?>
		</span>
		<span class="customer-privacy-policy-date info-item">
			<?php esc_html_e( 'Last Agreed to Privacy Policy', 'restropress' ); ?>:
			<?php if ( ! empty( $privacy_timestamp ) ) : ?>
				<?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' H:i:s', $privacy_timestamp ) ); ?>
				<?php if ( ! empty( $privacy_timestamps ) ) : ?>
					<?php
					$tooltip_text = esc_html__( 'Previous Agreement Dates', 'restropress' ) . "\n";

					foreach ( $privacy_timestamps as $timestamp ) {
						$tooltip_text .= esc_html( date_i18n( get_option( 'date_format' ) . ' H:i:s', $timestamp ) ) . "\n";
					}
					?>
					<span class="rpress-help-tip dashicons dashicons-editor-help" title="<?php echo esc_attr( $tooltip_text ); ?>"></span>
				<?php endif; ?>
			<?php else: ?>
				<?php
				if ( empty( $last_payment_date ) ) {
					esc_html_e( 'No date found.', 'restropress' );
				} else {
					echo esc_html( date_i18n( get_option( 'date_format' ) . ' H:i:s', $last_payment_date ) );
					?>
					<span alt="f223" class="rpress-help-tip dashicons dashicons-editor-help" title="<strong><?php esc_html_e( 'Estimated Privacy Policy Date', 'restropress' ); ?></strong><br /><?php esc_html_e( 'This customer made a purchase prior to privacy policy dates being logged, this is the date of their last purchase. If your site was displaying the privacy policy checkbox at that time, this is our best estimate as to when they last agreed to your privacy policy.', 'restropress' ); ?>"></span>
					<?php
				}
				?>
			<?php endif; ?>
		</span>
		<h3><?php esc_html_e( 'Notes', 'restropress' ); ?></h3>
		<?php if ( 1 == $paged ) : ?>
		<div style="display: block; margin-bottom: 35px;">
			<form id="rpress-add-customer-note" method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=rpress-customers&view=notes&id=' . $customer->id ) ) ; ?>">
				<textarea id="customer-note" name="customer_note" class="customer-note-input" rows="10"></textarea>
				<br />
				<input type="hidden" id="customer-id" name="customer_id" value="<?php echo esc_attr( $customer->id ); ?>" />
				<input type="hidden" name="rpress_action" value="add-customer-note" />
				<?php wp_nonce_field( 'add-customer-note', 'add_customer_note_nonce', true, true ); ?>
				<input id="add-customer-note" class="right button-primary" type="submit" value="Add Note" />
			</form>
		</div>
		<?php endif; ?>
		<?php
		$pagination_args = array(
			'base'     => '%_%',
			'format'   => '?paged=%#%',
			'total'    => $total_pages,
			'current'  => $paged,
			'show_all' => true
		);
		echo esc_url( paginate_links( $pagination_args ) ) ;
		?>
		<div id="rpress-customer-notes">
		<?php if ( count( $customer_notes ) > 0 ) : ?>
			<?php foreach( $customer_notes as $key => $note ) : ?>
				<div class="customer-note-wrapper dashboard-comment-wrap comment-item">
					<span class="note-content-wrap">
						<?php echo esc_html( stripslashes( $note ) ); ?>
					</span>
				</div>
			<?php endforeach; ?>
		<?php else: ?>
			<div class="rpress-no-customer-notes">
				<?php esc_html_e( 'No Customer Notes', 'restropress' ); ?>
			</div>
		<?php endif; ?>
		</div>
		<?php echo esc_url( paginate_links( $pagination_args ) ); ?>
	</div>
	<?php
}
function rpress_customers_delete_view( $customer ) {
	$customer_edit_role = apply_filters( 'rpress_edit_customers_role', 'edit_shop_payments' );
	?>
	<?php do_action( 'rpress_customer_delete_top', $customer ); ?>
	<div class="info-wrapper customer-section">
		<form id="delete-customer" method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=rpress-customers&view=delete&id=' . $customer->id ) ); ?>">
				<div class="rpress-item-notes-header">
				<?php echo get_avatar( $customer->email, 30 ); ?> <span><?php echo esc_html( $customer->name ); ?></span>
			</div>
			<div class="customer-info delete-customer">
				<span class="delete-customer-options">
					<p>
						<?php echo wp_kses_post( RPRESS()->html->checkbox( array( 'name' => 'rpress-customer-delete-confirm' ) ) ); ?>
						<label for="rpress-customer-delete-confirm"><?php esc_html_e( 'Are you sure you want to delete this customer?', 'restropress' ); ?></label>
					</p>
					<p>
						<?php echo wp_kses_post( RPRESS()->html->checkbox( array( 'name' => 'rpress-customer-delete-records', 'options' => array( 'disabled' => true ) ) ) ); ?>
						<label for="rpress-customer-delete-records"><?php esc_html_e( 'Delete all associated payments and records?', 'restropress' ); ?></label>
					</p>
					<?php do_action( 'rpress_customer_delete_inputs', $customer ); ?>
				</span>
				<span id="customer-edit-actions">
					<input type="hidden" name="customer_id" value="<?php echo esc_attr( $customer->id ); ?>" />
					<?php wp_nonce_field( 'delete-customer', '_wpnonce', false, true ); ?>
					<input type="hidden" name="rpress_action" value="delete-customer" />
					<input type="submit" disabled="disabled" id="rpress-delete-customer" class="button-primary" value="<?php esc_html_e( 'Delete Customer', 'restropress' ); ?>" />
					<a id="rpress-delete-customer-cancel" href="<?php echo esc_url( admin_url( 'admin.php?page=rpress-customers&view=overview&id=' . $customer->id ) ) ; ?>" class="delete"><?php esc_html_e( 'Cancel', 'restropress' ); ?></a>
				</span>
			</div>
		</form>
	</div>
	<?php
	do_action( 'rpress_customer_delete_bottom', $customer );
}
function rpress_customer_tools_view( $customer ) {
	$customer_edit_role = apply_filters( 'rpress_edit_customers_role', 'edit_shop_payments' );
	?>
	<?php do_action( 'rpress_customer_tools_top', $customer ); ?>
	<div class="info-wrapper customer-section">
		<div class="customer-notes-header">
			<?php echo get_avatar( $customer->email, 30 ); ?> <span><?php echo esc_html( $customer->name ); ?></span>
		</div>
		<h3><?php esc_html_e( 'Tools', 'restropress' ); ?></h3>
		<div class="rpress-item-info customer-info">
			<h4><?php esc_html_e( 'Recount Customer Stats', 'restropress' ); ?></h4>
			<p class="rpress-item-description"><?php esc_html_e( 'Use this tool to recalculate the purchase count and total value of the customer.', 'restropress' ); ?></p>
			<form method="post" id="rpress-tools-recount-form" class="rpress-export-form rpress-import-export-form">
				<span>
					<?php wp_nonce_field( 'rpress_ajax_export', 'rpress_ajax_export' ); ?>
					<input type="hidden" name="rpress-export-class" data-type="recount-single-customer-stats" value="RPRESS_Tools_Recount_Single_Customer_Stats" />
					<input type="hidden" name="customer_id" value="<?php echo esc_attr( $customer->id ); ?>" />
					<input type="submit" id="recount-stats-submit" value="<?php esc_html_e( 'Recount Stats', 'restropress' ); ?>" class="button-secondary"/>
					<span class="spinner"></span>
				</span>
			</form>
		</div>
	</div>
	<?php
	do_action( 'rpress_customer_tools_bottom', $customer );
}
/**
 * Display a notice on customer account if they are pending verification
 *
 * @since  1.0.0
 * @return void
 */
function rpress_verify_customer_notice( $customer ) {
	if ( ! rpress_user_pending_verification( $customer->user_id ) ) {
		return;
	}
	$url = wp_nonce_url( admin_url( 'admin.php?page=rpress-customers&view=overview&rpress_action=verify_user_admin&id=' . $customer->id ), 'rpress-verify-user' );
	echo '<div class="update error"><p>';
	esc_html_e( 'This customer\'s user account is pending verification.', 'restropress' );
	echo ' ';
	echo '<a href="' .esc_url( $url )  . '">' . esc_html__( 'Verify account.', 'restropress' ) . '</a>';
	echo "\n\n";
	echo '</p></div>';
}
add_action( 'rpress_customer_card_top', 'rpress_verify_customer_notice', 10, 1 );
